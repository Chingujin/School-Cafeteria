import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, MenuItem, CartItem, Order, OrderStatus, UserRole } from '../types';
import { mockUser, mockMenu } from '../data/mockData';

interface AppContextType {
  user: User | null;
  menu: MenuItem[];
  cart: CartItem[];
  orders: Order[];
  addToCart: (item: MenuItem, quantity?: number) => void;
  removeFromCart: (itemId: string) => void;
  updateCartQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (pickupTime: string) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  topUpBalance: (amount: number) => void;
  updateMenu: (updatedMenu: MenuItem[]) => void;
  setUserRole: (role: UserRole) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(mockUser);
  const [menu, setMenu] = useState<MenuItem[]>(mockMenu);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const addToCart = (item: MenuItem, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.menuItem.id === item.id);
      if (existing) {
        return prev.map((c) =>
          c.menuItem.id === item.id ? { ...c, quantity: c.quantity + quantity } : c
        );
      }
      return [...prev, { menuItem: item, quantity }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((c) => c.menuItem.id !== itemId));
  };

  const updateCartQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setCart((prev) =>
      prev.map((c) => (c.menuItem.id === itemId ? { ...c, quantity } : c))
    );
  };

  const clearCart = () => setCart([]);

  const placeOrder = async (pickupTime: string): Promise<Order> => {
    if (!user) throw new Error('Not logged in');
    
    const totalAmount = cart.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
    
    if (user.balance < totalAmount) {
      throw new Error('Insufficient balance');
    }

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));

    const newOrder: Order = {
      id: `ORD-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      userId: user.id,
      items: [...cart],
      totalAmount,
      status: 'pending',
      createdAt: new Date().toISOString(),
      pickupTime,
    };

    setUser(prev => prev ? { ...prev, balance: prev.balance - totalAmount } : null);
    setOrders(prev => [newOrder, ...prev]);
    clearCart();

    // Simulate order progression
    setTimeout(() => {
      updateOrderStatus(newOrder.id, 'preparing');
    }, 5000);
    
    setTimeout(() => {
      updateOrderStatus(newOrder.id, 'ready');
    }, 15000);

    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const topUpBalance = (amount: number) => {
    setUser(prev => prev ? { ...prev, balance: prev.balance + amount } : null);
  };

  const updateMenu = (updatedMenu: MenuItem[]) => {
    setMenu(updatedMenu);
  };

  const setUserRole = (role: UserRole) => {
    setUser(prev => prev ? { ...prev, role } : null);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        menu,
        cart,
        orders,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        placeOrder,
        updateOrderStatus,
        topUpBalance,
        updateMenu,
        setUserRole,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
