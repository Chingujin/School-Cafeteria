import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Utensils, ShoppingCart, Clock, User, ShieldAlert } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { cn } from '../lib/utils';

export default function BottomNav() {
  const { cart, user } = useAppContext();
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navItems = [
    { to: '/', icon: Home, label: 'Нүүр' },
    { to: '/menu', icon: Utensils, label: 'Цэс' },
    { to: '/cart', icon: ShoppingCart, label: 'Сагс', badge: cartItemCount },
    { to: '/orders', icon: Clock, label: 'Захиалга' },
    { to: '/profile', icon: User, label: 'Профайл' },
  ];

  if (user?.role === 'admin') {
    navItems.push({ to: '/admin', icon: ShieldAlert, label: 'Админ' });
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 max-w-md mx-auto">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center justify-center w-full h-full space-y-1 text-xs font-medium transition-colors relative',
                isActive ? 'text-orange-600' : 'text-gray-500 hover:text-gray-900'
              )
            }
          >
            <div className="relative">
              <item.icon className="w-6 h-6" />
              {item.badge ? (
                <span className="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                  {item.badge}
                </span>
              ) : null}
            </div>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
