import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, ChefHat, Clock, Package, MapPin, AlertCircle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function OrderStatus() {
  const { id } = useParams<{ id: string }>();
  const { orders } = useAppContext();
  const navigate = useNavigate();
  
  const order = orders.find(o => o.id === id);

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6 text-center">
        <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Захиалга олдсонгүй</h2>
        <button onClick={() => navigate('/orders')} className="text-orange-600 font-bold mt-4">Буцах</button>
      </div>
    );
  }

  const steps = [
    { id: 'pending', label: 'Хүлээгдэж байна', icon: Clock },
    { id: 'preparing', label: 'Бэлтгэж байна', icon: ChefHat },
    { id: 'ready', label: 'Бэлэн болсон', icon: Package },
  ];

  const currentStepIndex = steps.findIndex(s => s.id === order.status);
  const isCompleted = order.status === 'completed';
  const isCancelled = order.status === 'cancelled';

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      <header className="bg-white pt-12 pb-4 px-6 sticky top-0 z-40 shadow-sm flex items-center">
        <button onClick={() => navigate(-1)} className="mr-4 p-2 -ml-2 text-gray-600 hover:text-gray-900">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Захиалга #{order.id.split('-')[1]}</h1>
      </header>

      <main className="px-6 mt-6 space-y-6">
        
        {/* Status Tracker */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-6 text-center text-lg">
            {isCompleted ? 'Захиалга амжилттай авсан' : isCancelled ? 'Захиалга цуцлагдсан' : 'Таны захиалга'}
          </h2>
          
          {!isCompleted && !isCancelled && (
            <div className="relative">
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-100 -z-10"></div>
              
              <div className="space-y-8">
                {steps.map((step, index) => {
                  const isPast = currentStepIndex > index;
                  const isCurrent = currentStepIndex === index;
                  const StepIcon = step.icon;
                  
                  return (
                    <div key={step.id} className="flex items-center relative">
                      <div className={cn(
                        "w-12 h-12 rounded-full flex items-center justify-center border-4 border-white shadow-sm transition-colors duration-500",
                        isPast || isCurrent ? "bg-orange-500 text-white" : "bg-gray-100 text-gray-400"
                      )}>
                        <StepIcon className="w-5 h-5" />
                      </div>
                      <div className="ml-4">
                        <p className={cn(
                          "font-bold text-sm transition-colors duration-500",
                          isPast || isCurrent ? "text-gray-900" : "text-gray-400"
                        )}>
                          {step.label}
                        </p>
                        {isCurrent && (
                          <motion.p 
                            initial={{ opacity: 0, y: -5 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-xs text-orange-600 font-medium mt-1"
                          >
                            Одоо хийгдэж байна...
                          </motion.p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {order.status === 'ready' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-8 bg-green-50 border border-green-200 p-4 rounded-xl text-center"
            >
              <h3 className="text-green-800 font-bold mb-1">Хоол бэлэн боллоо! 🎉</h3>
              <p className="text-green-600 text-sm">Та цайны газар очиж хоолоо авна уу.</p>
            </motion.div>
          )}
        </div>

        {/* Order Details */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-4 border-b border-gray-100 pb-3">Захиалгын мэдээлэл</h3>
          
          <div className="space-y-3 mb-4">
            {order.items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <div className="flex items-center">
                  <span className="text-sm font-bold text-gray-900 w-6">{item.quantity}x</span>
                  <span className="text-sm text-gray-600">{item.menuItem.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">{formatCurrency(item.menuItem.price * item.quantity)}</span>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-100 pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Авах цаг</span>
              <span className="font-bold text-gray-900">{order.pickupTime}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Нийт дүн</span>
              <span className="font-bold text-orange-600 text-lg">{formatCurrency(order.totalAmount)}</span>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
