import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Flame, Clock, Wallet } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency } from '../lib/utils';
import { motion } from 'motion/react';

export default function Home() {
  const { user, menu } = useAppContext();
  
  const popularItems = menu.filter(item => item.isPopular && !item.isSoldOut).slice(0, 3);
  const todaySpecials = menu.filter(item => !item.isSoldOut).slice(0, 2);

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-orange-600 text-white pt-12 pb-6 px-6 rounded-b-3xl shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/4 -translate-y-1/4">
          <svg width="200" height="200" viewBox="0 0 200 200" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <circle cx="100" cy="100" r="100" />
          </svg>
        </div>
        
        <div className="flex justify-between items-start relative z-10">
          <div>
            <h1 className="text-2xl font-bold mb-1">Сайн уу, {user?.name.split(' ')[0]}! 👋</h1>
            <p className="text-orange-100 text-sm">Өнөөдөр юу идэх вэ?</p>
          </div>
          <Link to="/profile" className="bg-white/20 p-2 rounded-full backdrop-blur-sm">
            <UserAvatar name={user?.name || ''} />
          </Link>
        </div>

        {/* Balance Card */}
        <div className="mt-6 bg-white rounded-2xl p-4 shadow-lg text-gray-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-orange-100 p-2 rounded-xl">
              <Wallet className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Үлдэгдэл</p>
              <p className="text-xl font-bold">{formatCurrency(user?.balance || 0)}</p>
            </div>
          </div>
          <Link to="/profile" className="bg-orange-50 text-orange-600 px-3 py-1.5 rounded-lg text-sm font-semibold hover:bg-orange-100 transition">
            Цэнэглэх
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 mt-6 space-y-8">
        
        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Link to="/menu" className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center space-y-2 hover:border-orange-200 transition">
            <div className="bg-orange-50 p-3 rounded-full">
              <Flame className="w-6 h-6 text-orange-500" />
            </div>
            <span className="font-semibold text-gray-800">Захиалах</span>
          </Link>
          <Link to="/orders" className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center space-y-2 hover:border-orange-200 transition">
            <div className="bg-blue-50 p-3 rounded-full">
              <Clock className="w-6 h-6 text-blue-500" />
            </div>
            <span className="font-semibold text-gray-800">Түүх</span>
          </Link>
        </div>

        {/* Popular Items */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-lg font-bold text-gray-900">Эрэлттэй хоолнууд</h2>
            <Link to="/menu" className="text-sm text-orange-600 font-medium flex items-center">
              Бүгд <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          
          <div className="flex overflow-x-auto pb-4 -mx-6 px-6 space-x-4 snap-x hide-scrollbar">
            {popularItems.map((item, idx) => (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={item.id} 
                className="min-w-[160px] bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden snap-start flex-shrink-0"
              >
                <div className="h-32 bg-gray-200 relative">
                  <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-bold text-orange-600 flex items-center">
                    <Flame className="w-3 h-3 mr-1" /> Эрэлттэй
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-900 text-sm truncate">{item.name}</h3>
                  <p className="text-orange-600 font-bold mt-1">{formatCurrency(item.price)}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Today's Special */}
        <section>
          <h2 className="text-lg font-bold text-gray-900 mb-4">Өнөөдрийн онцлох</h2>
          <div className="space-y-4">
            {todaySpecials.map((item, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + idx * 0.1 }}
                key={item.id} 
                className="bg-white rounded-2xl p-3 shadow-sm border border-gray-100 flex items-center space-x-4"
              >
                <img src={item.imageUrl} alt={item.name} className="w-20 h-20 rounded-xl object-cover" />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900">{item.name}</h3>
                  <p className="text-xs text-gray-500 mt-1 line-clamp-1">{item.description}</p>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-orange-600 font-bold">{formatCurrency(item.price)}</span>
                    <Link to="/menu" className="bg-gray-900 text-white text-xs px-3 py-1.5 rounded-lg font-medium">
                      Нэмэх
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

      </main>
    </div>
  );
}

function UserAvatar({ name }: { name: string }) {
  const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  return (
    <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-sm">
      {initials}
    </div>
  );
}
