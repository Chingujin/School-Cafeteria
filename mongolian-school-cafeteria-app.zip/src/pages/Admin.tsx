import React, { useState } from 'react';
import { ShieldAlert, Plus, Edit2, Trash2, Check, X } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';
import { MenuItem } from '../types';

export default function Admin() {
  const { user, menu, updateMenu } = useAppContext();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<MenuItem>>({});

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6 text-center">
        <ShieldAlert className="w-12 h-12 text-red-500 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Хандах эрхгүй</h2>
        <p className="text-gray-500">Энэ хуудсанд зөвхөн админ хандах боломжтой.</p>
      </div>
    );
  }

  const handleEdit = (item: MenuItem) => {
    setEditingId(item.id);
    setEditForm(item);
  };

  const handleSave = () => {
    if (editingId) {
      updateMenu(menu.map(item => item.id === editingId ? { ...item, ...editForm } as MenuItem : item));
      setEditingId(null);
    }
  };

  const handleToggleSoldOut = (id: string, currentStatus: boolean) => {
    updateMenu(menu.map(item => item.id === id ? { ...item, isSoldOut: !currentStatus } : item));
  };

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      <header className="bg-white pt-12 pb-4 px-6 sticky top-0 z-40 shadow-sm flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Админ</h1>
        <button className="bg-orange-600 text-white p-2 rounded-xl shadow-sm hover:bg-orange-700 transition">
          <Plus className="w-5 h-5" />
        </button>
      </header>

      <main className="px-6 mt-6 space-y-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex justify-between items-center mb-6">
          <div>
            <p className="text-sm text-gray-500 font-medium">Өнөөдрийн орлого</p>
            <h3 className="text-2xl font-bold text-gray-900">{formatCurrency(125000)}</h3>
          </div>
          <div className="bg-green-50 text-green-600 px-3 py-1 rounded-lg text-sm font-bold">
            +15%
          </div>
        </div>

        <h2 className="text-lg font-bold text-gray-900 mb-4">Цэс удирдах</h2>
        
        <div className="space-y-4">
          {menu.map(item => (
            <div key={item.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              {editingId === item.id ? (
                <div className="space-y-3">
                  <input 
                    type="text" 
                    value={editForm.name} 
                    onChange={e => setEditForm({...editForm, name: e.target.value})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold"
                  />
                  <div className="flex space-x-2">
                    <input 
                      type="number" 
                      value={editForm.price} 
                      onChange={e => setEditForm({...editForm, price: Number(e.target.value)})}
                      className="w-1/2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm"
                    />
                    <input 
                      type="number" 
                      value={editForm.stock} 
                      onChange={e => setEditForm({...editForm, stock: Number(e.target.value)})}
                      className="w-1/2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm"
                      placeholder="Үлдэгдэл"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-2">
                    <button onClick={() => setEditingId(null)} className="p-2 text-gray-500 bg-gray-100 rounded-lg"><X className="w-4 h-4" /></button>
                    <button onClick={handleSave} className="p-2 text-white bg-green-500 rounded-lg"><Check className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <img src={item.imageUrl} alt={item.name} className={cn("w-16 h-16 rounded-xl object-cover", item.isSoldOut && "grayscale")} />
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 text-sm">{item.name}</h3>
                    <p className="text-orange-600 font-bold text-sm">{formatCurrency(item.price)}</p>
                    <p className="text-xs text-gray-500 mt-1">Үлдэгдэл: {item.stock}</p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <button 
                      onClick={() => handleToggleSoldOut(item.id, item.isSoldOut)}
                      className={cn(
                        "text-xs font-bold px-2 py-1 rounded-md transition",
                        item.isSoldOut ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                      )}
                    >
                      {item.isSoldOut ? 'Сэргээх' : 'Дууссан'}
                    </button>
                    <button onClick={() => handleEdit(item)} className="text-blue-600 p-1 bg-blue-50 rounded-md flex justify-center">
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
