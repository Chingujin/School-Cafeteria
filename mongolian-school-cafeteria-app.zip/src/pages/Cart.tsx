import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ArrowRight, Clock, AlertCircle, ShoppingCart } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function Cart() {
  const { cart, updateCartQuantity, removeFromCart, placeOrder, user } = useAppContext();
  const navigate = useNavigate();
  const [isOrdering, setIsOrdering] = useState(false);
  const [pickupTime, setPickupTime] = useState('12:00');
  const [error, setError] = useState('');

  const totalAmount = cart.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
  const hasInsufficientBalance = user ? user.balance < totalAmount : true;

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    if (hasInsufficientBalance) {
      setError('Үлдэгдэл хүрэлцэхгүй байна. Цэнэглэнэ үү.');
      return;
    }

    setIsOrdering(true);
    setError('');
    try {
      const order = await placeOrder(pickupTime);
      navigate(`/orders/${order.id}`);
    } catch (err: any) {
      setError(err.message || 'Алдаа гарлаа');
      setIsOrdering(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
          <ShoppingCart className="w-10 h-10 text-gray-400" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Сагс хоосон байна</h2>
        <p className="text-gray-500 mb-8">Та цэснээс хоол сонгож сагсандаа нэмээрэй.</p>
        <Link to="/menu" className="bg-orange-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-700 transition">
          Цэс рүү очих
        </Link>
      </div>
    );
  }

  return (
    <div className="pb-32 bg-gray-50 min-h-screen relative">
      <header className="bg-white pt-12 pb-4 px-6 sticky top-0 z-40 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">Сагс</h1>
      </header>

      <main className="px-6 mt-6">
        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {cart.map((item) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                key={item.menuItem.id}
                className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4"
              >
                <img src={item.menuItem.imageUrl} alt={item.menuItem.name} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" />
                
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 text-sm">{item.menuItem.name}</h3>
                  <p className="text-orange-600 font-bold mt-1 text-sm">{formatCurrency(item.menuItem.price)}</p>
                </div>

                <div className="flex flex-col items-end space-y-2">
                  <button 
                    onClick={() => removeFromCart(item.menuItem.id)}
                    className="text-gray-400 hover:text-red-500 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  
                  <div className="flex items-center bg-gray-100 rounded-lg p-1">
                    <button 
                      onClick={() => updateCartQuantity(item.menuItem.id, item.quantity - 1)}
                      className="w-6 h-6 flex items-center justify-center bg-white rounded shadow-sm text-gray-600"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-bold text-sm">{item.quantity}</span>
                    <button 
                      onClick={() => updateCartQuantity(item.menuItem.id, item.quantity + 1)}
                      className="w-6 h-6 flex items-center justify-center bg-orange-600 rounded shadow-sm text-white"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Pickup Time */}
        <div className="mt-8 bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-4 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-orange-500" /> Авах цаг
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {['11:30', '12:00', '12:30', '13:00', '13:30', '14:00'].map((time) => (
              <button
                key={time}
                onClick={() => setPickupTime(time)}
                className={cn(
                  "py-2 rounded-xl text-sm font-bold border transition-colors",
                  pickupTime === time 
                    ? "bg-orange-50 border-orange-500 text-orange-600" 
                    : "bg-white border-gray-200 text-gray-600 hover:border-orange-300"
                )}
              >
                {time}
              </button>
            ))}
          </div>
        </div>
      </main>

      {/* Checkout Bar */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-100 p-4 pb-6 max-w-md mx-auto shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)]">
        <div className="flex justify-between items-center mb-4 px-2">
          <span className="text-gray-500 font-medium">Нийт дүн</span>
          <span className="text-2xl font-bold text-gray-900">{formatCurrency(totalAmount)}</span>
        </div>
        
        <button
          onClick={handleCheckout}
          disabled={isOrdering || cart.length === 0}
          className={cn(
            "w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center transition-all",
            hasInsufficientBalance 
              ? "bg-gray-200 text-gray-500 cursor-not-allowed" 
              : "bg-orange-600 text-white hover:bg-orange-700 active:scale-[0.98] shadow-lg shadow-orange-600/30"
          )}
        >
          {isOrdering ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Боловсруулж байна...
            </span>
          ) : hasInsufficientBalance ? (
            "Үлдэгдэл хүрэлцэхгүй"
          ) : (
            <>
              Захиалах <ArrowRight className="w-5 h-5 ml-2" />
            </>
          )}
        </button>
      </div>
    </div>
  );
}

