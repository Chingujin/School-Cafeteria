import React, { useState } from 'react';
import { Search, Plus, Minus, Flame, AlertCircle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { MenuItem } from '../types';

const CATEGORIES = [
  { id: 'all', label: 'Бүгд' },
  { id: 'breakfast', label: 'Өглөөний цай' },
  { id: 'lunch', label: 'Өдрийн хоол' },
  { id: 'drinks', label: 'Уух зүйлс' },
  { id: 'snacks', label: 'Хөнгөн зууш' },
];

export default function Menu() {
  const { menu, addToCart, cart, updateCartQuantity } = useAppContext();
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMenu = menu.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white pt-12 pb-4 px-6 sticky top-0 z-40 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Цэс</h1>
        
        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Хоол хайх..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-100 border-transparent focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-200 rounded-xl py-3 pl-10 pr-4 text-sm transition-all outline-none"
          />
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto space-x-2 pb-2 -mx-6 px-6 hide-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors',
                activeCategory === cat.id
                  ? 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </header>

      {/* Menu List */}
      <main className="px-6 mt-6">
        <AnimatePresence mode="popLayout">
          {filteredMenu.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center text-gray-500 mt-12"
            >
              <p>Илэрц олдсонгүй.</p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredMenu.map((item) => (
                <MenuItemCard 
                  key={item.id} 
                  item={item} 
                  cartQuantity={cart.find(c => c.menuItem.id === item.id)?.quantity || 0}
                  onAdd={() => addToCart(item)}
                  onUpdate={(qty) => updateCartQuantity(item.id, qty)}
                />
              ))}
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

const MenuItemCard: React.FC<{ item: MenuItem, cartQuantity: number, onAdd: () => void, onUpdate: (qty: number) => void }> = ({ item, cartQuantity, onAdd, onUpdate }) => {
  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className={cn(
        "bg-white rounded-2xl p-3 shadow-sm border border-gray-100 flex space-x-4 relative overflow-hidden",
        item.isSoldOut && "opacity-60 grayscale-[0.5]"
      )}
    >
      {/* Image */}
      <div className="w-24 h-24 rounded-xl overflow-hidden relative flex-shrink-0">
        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
        {item.isPopular && !item.isSoldOut && (
          <div className="absolute top-1 left-1 bg-orange-500 text-white p-1 rounded-md">
            <Flame className="w-3 h-3" />
          </div>
        )}
        {item.isSoldOut && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="text-white text-[10px] font-bold uppercase tracking-wider px-2 py-1 bg-red-600 rounded">Дууссан</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-between py-1">
        <div>
          <div className="flex justify-between items-start">
            <h3 className="font-bold text-gray-900 text-sm leading-tight">{item.name}</h3>
          </div>
          <p className="text-xs text-gray-500 mt-1 line-clamp-2">{item.description}</p>
        </div>
        
        <div className="flex justify-between items-end mt-2">
          <div className="flex flex-col">
            <span className="text-orange-600 font-bold text-sm">{formatCurrency(item.price)}</span>
            {item.stock > 0 && item.stock <= 10 && !item.isSoldOut && (
              <span className="text-[10px] text-red-500 font-medium flex items-center mt-0.5">
                <AlertCircle className="w-3 h-3 mr-0.5" /> Зөвхөн {item.stock} үлдсэн
              </span>
            )}
          </div>

          {!item.isSoldOut && (
            <div className="flex items-center">
              {cartQuantity > 0 ? (
                <div className="flex items-center bg-gray-100 rounded-lg p-1">
                  <button 
                    onClick={() => onUpdate(cartQuantity - 1)}
                    className="w-7 h-7 flex items-center justify-center bg-white rounded-md shadow-sm text-gray-600 hover:text-orange-600"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-bold text-sm">{cartQuantity}</span>
                  <button 
                    onClick={() => onUpdate(cartQuantity + 1)}
                    className="w-7 h-7 flex items-center justify-center bg-orange-600 rounded-md shadow-sm text-white hover:bg-orange-700"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button 
                  onClick={onAdd}
                  className="bg-gray-900 text-white text-xs font-semibold px-4 py-2 rounded-xl hover:bg-gray-800 transition active:scale-95"
                >
                  Нэмэх
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
