import React, { useState } from 'react';
import { User, Wallet, CreditCard, LogOut, ChevronRight, Settings, Bell } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';

export default function Profile() {
  const { user, topUpBalance, setUserRole } = useAppContext();
  const [showTopUp, setShowTopUp] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState<number>(5000);

  if (!user) return null;

  const handleTopUp = () => {
    topUpBalance(topUpAmount);
    setShowTopUp(false);
  };

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      <header className="bg-white pt-12 pb-6 px-6 sticky top-0 z-40 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">Профайл</h1>
      </header>

      <main className="px-6 mt-6 space-y-6">
        
        {/* User Info */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-center space-x-4">
          <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold text-xl">
            {user.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2)}
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-bold text-gray-900">{user.name}</h2>
            <select 
              value={user.role}
              onChange={(e) => setUserRole(e.target.value as any)}
              className="text-sm text-gray-500 bg-transparent border-none outline-none mt-1"
            >
              <option value="student">Сурагч</option>
              <option value="teacher">Багш</option>
              <option value="admin">Админ</option>
            </select>
          </div>
        </div>

        {/* Wallet */}
        <div className="bg-gradient-to-br from-orange-500 to-red-500 p-6 rounded-3xl shadow-lg text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/4 -translate-y-1/4">
            <svg width="200" height="200" viewBox="0 0 200 200" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <circle cx="100" cy="100" r="100" />
            </svg>
          </div>
          
          <div className="relative z-10 flex justify-between items-start">
            <div>
              <p className="text-orange-100 text-sm font-medium uppercase tracking-wider mb-1">Үлдэгдэл</p>
              <h3 className="text-3xl font-bold">{formatCurrency(user.balance)}</h3>
            </div>
            <Wallet className="w-8 h-8 text-orange-200" />
          </div>

          <button 
            onClick={() => setShowTopUp(true)}
            className="mt-6 w-full bg-white text-orange-600 py-3 rounded-xl font-bold hover:bg-orange-50 transition active:scale-[0.98]"
          >
            Цэнэглэх
          </button>
        </div>

        {/* Top Up Modal */}
        {showTopUp && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Данс цэнэглэх</h3>
              
              <div className="grid grid-cols-3 gap-3 mb-6">
                {[5000, 10000, 20000].map(amount => (
                  <button
                    key={amount}
                    onClick={() => setTopUpAmount(amount)}
                    className={cn(
                      "py-2 rounded-xl text-sm font-bold border transition-colors",
                      topUpAmount === amount 
                        ? "bg-orange-50 border-orange-500 text-orange-600" 
                        : "bg-white border-gray-200 text-gray-600 hover:border-orange-300"
                    )}
                  >
                    {formatCurrency(amount).replace('₮', '')}
                  </button>
                ))}
              </div>

              <div className="flex space-x-3">
                <button 
                  onClick={() => setShowTopUp(false)}
                  className="flex-1 py-3 rounded-xl font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition"
                >
                  Цуцлах
                </button>
                <button 
                  onClick={handleTopUp}
                  className="flex-1 py-3 rounded-xl font-bold text-white bg-orange-600 hover:bg-orange-700 transition"
                >
                  Цэнэглэх
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Menu Items */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <ProfileMenuItem icon={CreditCard} label="Төлбөрийн хэрэгсэл" />
          <ProfileMenuItem icon={Bell} label="Мэдэгдэл" />
          <ProfileMenuItem icon={Settings} label="Тохиргоо" />
          <div className="border-t border-gray-100">
            <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition text-red-600">
              <div className="flex items-center space-x-3">
                <div className="bg-red-50 p-2 rounded-xl">
                  <LogOut className="w-5 h-5" />
                </div>
                <span className="font-medium">Гарах</span>
              </div>
            </button>
          </div>
        </div>

      </main>
    </div>
  );
}

function ProfileMenuItem({ icon: Icon, label }: { icon: any, label: string }) {
  return (
    <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition border-b border-gray-100 last:border-0">
      <div className="flex items-center space-x-3">
        <div className="bg-gray-50 p-2 rounded-xl text-gray-600">
          <Icon className="w-5 h-5" />
        </div>
        <span className="font-medium text-gray-700">{label}</span>
      </div>
      <ChevronRight className="w-5 h-5 text-gray-400" />
    </button>
  );
}
