import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, CheckCircle2, ChefHat, Package, XCircle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency, cn } from '../lib/utils';
import { format } from 'date-fns';
import { OrderStatus as StatusType } from '../types';

const statusConfig: Record<StatusType, { icon: any, color: string, label: string }> = {
  pending: { icon: Clock, color: 'text-yellow-500 bg-yellow-50', label: 'Хүлээгдэж байна' },
  preparing: { icon: ChefHat, color: 'text-orange-500 bg-orange-50', label: 'Бэлтгэж байна' },
  ready: { icon: Package, color: 'text-green-500 bg-green-50', label: 'Бэлэн болсон' },
  completed: { icon: CheckCircle2, color: 'text-gray-500 bg-gray-100', label: 'Авсан' },
  cancelled: { icon: XCircle, color: 'text-red-500 bg-red-50', label: 'Цуцлагдсан' },
};

export default function Orders() {
  const { orders } = useAppContext();

  if (orders.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
          <Clock className="w-10 h-10 text-gray-400" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Захиалга алга</h2>
        <p className="text-gray-500 mb-8">Таны захиалгын түүх хоосон байна.</p>
        <Link to="/menu" className="bg-orange-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-700 transition">
          Хоол захиалах
        </Link>
      </div>
    );
  }

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      <header className="bg-white pt-12 pb-4 px-6 sticky top-0 z-40 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">Захиалгын түүх</h1>
      </header>

      <main className="px-6 mt-6 space-y-4">
        {orders.map((order) => {
          const config = statusConfig[order.status];
          const StatusIcon = config.icon;

          return (
            <Link 
              key={order.id} 
              to={`/orders/${order.id}`}
              className="block bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:border-orange-200 transition"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <span className="text-xs text-gray-400 font-medium">Захиалга #{order.id.split('-')[1]}</span>
                  <p className="text-sm font-bold text-gray-900 mt-0.5">
                    {format(new Date(order.createdAt), 'yyyy-MM-dd HH:mm')}
                  </p>
                </div>
                <div className={cn("flex items-center px-2.5 py-1 rounded-lg text-xs font-bold", config.color)}>
                  <StatusIcon className="w-3.5 h-3.5 mr-1.5" />
                  {config.label}
                </div>
              </div>

              <div className="border-t border-gray-100 pt-3 mt-3 flex justify-between items-end">
                <div className="text-sm text-gray-600">
                  {order.items.length} төрлийн хоол
                </div>
                <div className="text-right">
                  <span className="text-xs text-gray-500 block mb-0.5">Нийт дүн</span>
                  <span className="font-bold text-orange-600">{formatCurrency(order.totalAmount)}</span>
                </div>
              </div>
            </Link>
          );
        })}
      </main>
    </div>
  );
}
